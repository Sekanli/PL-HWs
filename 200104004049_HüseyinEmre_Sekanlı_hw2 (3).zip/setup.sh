#!/bin/bash

# Define the directory where the script and Lisp file are located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Name of the Lisp file
LISP_FILE="gpp_lexer.lisp"

# Check if the Lisp file exists in the script directory
if [ ! -f "$SCRIPT_DIR/$LISP_FILE" ]; then
    echo "Lisp file $LISP_FILE does not exist in $SCRIPT_DIR"
    exit 1
fi

# Create a directory in the local bin to place our script
# If you want to use a system-wide directory, you would typically use /usr/local/bin
# For user-specific installations, we use the home directory's bin
BIN_DIR="$HOME/bin"
mkdir -p "$BIN_DIR"

# Create a wrapper script for the Lisp interpreter command
WRAPPER_SCRIPT="$BIN_DIR/g++"

# Write the wrapper script
cat > "$WRAPPER_SCRIPT" <<EOF
#!/bin/bash

# Call SBCL with the script and pass all arguments
sbcl --script "$SCRIPT_DIR/$LISP_FILE" "\$@"
EOF

# Make the wrapper script executable
chmod +x "$WRAPPER_SCRIPT"

# Add the local bin directory to PATH if it's not already there
if [[ ":$PATH:" != ":$BIN_DIR:" ]]; then
    echo "export PATH=\$PATH:$BIN_DIR" >> "$HOME/.bashrc"
    echo "The path to the bin directory has been added to your .bashrc file."
    echo "Please run 'source \$HOME/.bashrc' to update your current session or restart your terminal."
fi

# Finish up
echo "Setup complete! You can now use 'g++' command to run your Lisp program."
