% test ?- available_delivery_personnel(obj2, Personnel).

%?- available_delivery_personnel(obj3, Personnel).

%?- available_delivery_personnel(obj5, Personnel).


% Define delivery personnel with their attributes (per id, kg capacity, work hour,remaining hour, position)
delivery_person(per1, 10, 12, 12, none, library).
delivery_person(per2, 15, 16, 16, none, cafeteria).
delivery_person(per3, 20, 8, 8, obj5, admin_office).

% Define objects to be delivered ( obj id , weight, pickup,delivery,urgency,currentcarrying person)
object(obj1, 5, admin_office, engineering_bld, medium, none).
object(obj2, 7, library, admin_office, high, none).
object(obj3, 4, cafeteria, socials_bld, low, none).
object(obj4, 3, engineering_bld, lecturehall_a, high, none).
object(obj5, 2, socials_bld, institute_x, medium, per3).

% Define the routes
route(admin_office, engineering_bld, 3).
route(library, engineering_bld, 5).
route(admin_office, library, 1).
route(admin_office, cafeteria, 4).
route(cafeteria, library, 5).
route(cafeteria, socials_bld, 2).
route(engineering_bld, lecturehall_a, 2).
route(socials_bld, library, 2).
route(institute_y, library, 3).
route(socials_bld, institute_x, 8).
route(lecturehall_a, institute_y, 3).

% Define the connected predicate
connected(X, Y, Distance) :- 
    route(X, Y, Distance) ; 
    route(Y, X, Distance).
  
% Urgency ranking
urgency_rank(low, 1).
urgency_rank(medium, 2).
urgency_rank(high, 3).

% Compare urgencies
urgency_higher_than(Urgency1, Urgency2) :-
    urgency_rank(Urgency1, Rank1),
    urgency_rank(Urgency2, Rank2),
    Rank1 > Rank2.
    

% Find the shortest path from Start to End
find_shortest_path(Start, End, Path, MinDistance) :-
    setof((D, P), depth_first_search(Start, End, [Start], 0, P, D), [(_, RevPath)|_]),
    reverse(RevPath, Path),
    Path = [_|Tail],
    compute_distance(Tail, Start, MinDistance).

% Depth-first search
depth_first_search(End, End, Path, Distance, Path, Distance).
depth_first_search(Start, End, Visited, AccDistance, Path, TotalDistance) :-
    connected(Start, Next, Distance),
    \+ member(Next, Visited),
    NewDistance is AccDistance + Distance,
    depth_first_search(Next, End, [Next|Visited], NewDistance, Path, TotalDistance).

% Compute the total distance for the found path
compute_distance([End], Start, Distance) :-
    connected(Start, End, Distance), !.
compute_distance([Next|Rest], Start, TotalDistance) :-
    connected(Start, Next, Distance),
    compute_distance(Rest, Next, RestDistance),
    TotalDistance is Distance + RestDistance.

    
    
% Predicate to find available delivery personnel for an object or indicate if it's in transit
available_delivery_personnel(ObjectID, AvailablePersonnel) :-
    object(ObjectID, Weight, Pickup, Destination, Urgency, AssignedPersonnel),
    (   AssignedPersonnel \= none ->
        format('Object ~w is already in transit with personnel ~w.\n', [ObjectID, AssignedPersonnel]),
        !, AvailablePersonnel = []
    ;   findall((PersonID, TotalTime),
                (   delivery_person(PersonID, Capacity, _, RemainingWorkHours, Carrying, CurrentLocation),
                    (   Carrying = none
                    ;   object(Carrying, _, _, _, CarryingUrgency, _),
                        urgency_higher_than(Urgency, CarryingUrgency)
                    ),  
                    Capacity >= Weight,
                    (   CurrentLocation == Pickup ->
                        PickupTime = 0
                    ;   find_shortest_path(CurrentLocation, Pickup, _, PickupTime)
                    ),
                    find_shortest_path(Pickup, Destination, _, DeliveryTime),
                    TotalTime is PickupTime + DeliveryTime,
                    TotalTime =< RemainingWorkHours
                ),
                PersonnelList),
        format_personnel_list(PersonnelList, AvailablePersonnel)
    ).

% Format personnel list with time only
format_personnel_list([], []).
format_personnel_list([(PersonID, TotalTime)|Rest], [Result|FormattedRest]) :-
    format(atom(Result), '(~w, Time: ~w)', [PersonID, TotalTime]),
    format_personnel_list(Rest, FormattedRest).
    
